library(igraph)

#wiki_graph<-read.graph("wikipedia.gml", format="gml")
#lpc<-label.propagation.community(wiki_graph)
install.packages("igraphdata")
library(igraphdata)
data(package = "igraphdata")

data("USairports")

plot(USairports)
wca<-walktrap.community(USairports)
karate <- graph.famous("Zachary")
#airport <- graph.famous("USairports")
wc <- walktrap.community(karate)
modularity(wc)
membership(wc)
#[1] 1 1 2 1 5 5 5 1 2 2 5 1 1 2 3 3 5 1 3 1 3 1 3 4 4 4 3 4 2 3 2 2 3 3
plot(wc, karate)
plot(karate, vertex.color=membership(wc))

library(dplyr)
unique(membership(wc))

edge(wc)
edges(wc)
edge(karate)


run_community_algorithms<-function(data){
  karate_list<-list()
  karate_list<-walktrap.community(data)
  return(karate_list)
}

run_modularity<-function(data){
  modularity_list<-list()
  modularity_list<-modularity(karate_df)
  return(modularity_list)
}


karate_df<-run_community_algorithms(karate)
modularity_df<-run_modularity(karate_df)

