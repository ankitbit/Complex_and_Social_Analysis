
library(igraph)

# Generic function that takes any graph data as input and returns the modularity vector 
run_modularity<-function(data){
  #
  modularity_list<-numeric(9)
  
  #Computing Mdularities
  modularity_list[1]<-modularity(edge.betweenness.community(data))
  modularity_list[2]<-modularity(fastgreedy.community(data))
  modularity_list[3]<-modularity(label.propagation.community(data))
  modularity_list[4]<-modularity(leading.eigenvector.community(data))
  modularity_list[5]<-modularity(multilevel.community(data))
  modularity_list[6]<-modularity(optimal.community(data))
  modularity_list[7]<-modularity(spinglass.community(data))
  modularity_list[8]<-modularity(walktrap.community(data))
  modularity_list[9]<-modularity(infomap.community(data))

  return(modularity_list)
}

karate_modularity<-list()
karate_modularity<-run_modularity(karate)

karate_edges<-edge(karate)[1]














sum(crossing(wc, karate))

membership(wc)==1

crossing(wc, karate)

#--------------------------------------FUNCTION--------------------------------------------------------
# Function for computing the number of elements (nodes) in each Cluster for an object returned after
# applying a particular Community Detection Algorithm
compute_number_of_nodes_in_cluster<-function(community_object){
#computing the number of Cluserts ( #C ) using "length(unique(membership(data)))"
#Computing the number of nodes in each cluster #N_C
N_C<-numeric(length(unique(membership(community_object)))) #Creating a numeric vector of size= ( #C )

#Iterating over the number of clusters
for(i in 1:length(unique(membership(community_object)))){
  N_C[i]<-sum(membership(community_object)==i)
}
return(N_C)
}
#------------------------------------------------------------------------------------------------------
karate_walktrap_nc<-compute_number_of_nodes_in_cluster(wc)



#Finding the index of nodes belonging to cluster 

karate_community_index<-list() 
temp<-1
for(i in compute_number_of_nodes_in_cluster(wc)){
  if(temp<length(unique(membership(wc))))
  temp_vec<-(numeric(sum(membership(wc)==temp)))
  
  j<-1
  for(k in 1:vcount(karate)) {
    #vcount is used for computing number of nodes of the graph under consideration
    if((membership(wc)==temp)[k] ==T){
      temp_vec[j]<-k
      j<-j+1
    }
    
  }
  karate_community_index[temp]<-list(temp_vec)
  temp<-temp+1;
}






#stores the information about elements in each cluster for each of the different clusters

out_going_cluster_nodes<-numeric(5)
for(temp in 1:length(karate_community_index)){
  
  for(i in karate_community_index[[temp]]){
    for(j in 1:vcount(karate)){
      if(edge_wc[[1]][i][j]==1){
        #if node i and node j have an edge between them
        if(!j%in%karate_community_index[[temp]]){
          #if the node j is not a member of the particular cluster under consideration
          out_going_cluster_nodes[temp]<-out_going_cluster_nodes[temp]+1
        }
      }
    }
    
  }
}
#21 13  1  1 22
out_going_cluster_nodes<-numeric(5)
for(i in karate_community_index[[1]]){
  for(j in 1:34){
    if(edge_wc[[1]][i][j]==1){
      #if node i and node j have an edge between them
      if(!j%in%karate_community_index[[1]]){
        #if the node j is not a member of the particular cluster under consideration
        out_going_cluster_nodes[1]<-out_going_cluster_nodes[1]+1
      }
    }
  }
  
}

sum<-0
for(i in 1:length(wc)){
  sum<-sum + (karate_walktrap_nc[i]/vcount(karate))*(out_going_cluster_nodes[i]/karate_walktrap_nc[i])
}

