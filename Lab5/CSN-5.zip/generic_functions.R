


  # Function for computing the number of elements (nodes) in each Cluster for an object returned after
  # applying a particular Community Detection Algorithm
  
  
  
#This generic function creates a list with elements of this list as index of nodes in different 
#clusters for each of the clusters that our community algorithm has generated

compute_community_index<-function(data, community_object){
  community_index<-list()
  temp<-1
  for(i in compute_number_of_nodes_in_cluster(community_object)){
    if(temp<length(unique(membership(community_object))))
      temp_vec<-(numeric(sum(membership(community_object)==temp)))
    
    j<-1
    for(k in 1:vcount(data)) {
      #vcount is used for computing number of nodes of the graph under consideration
      if((membership(community_object)==temp)[k] ==T){
        temp_vec[j]<-k
        j<-j+1
      }
      
    }
    community_index[temp]<-list(temp_vec)
    temp<-temp+1;
  }
  return(community_index)
  
}  
  
  
  
  
  
  
#stores the information about elements in each cluster for each of the different clusters
#This function computes how many nodes are outgoing from each of the clusters for a given object
#returned by some community detection algorithm
compute_outgoing_nodes_from_clusters<-function(data, community_object){
  
  out_going_cluster_nodes<-numeric(length(unique(membership(community_object))))
  
  community_index<-compute_community_index(data, community_object)
  edge_community_object<-edge(data)
  
  for(temp in 1:length(community_index)){
    
    for(i in community_index[[temp]]){
      for(j in 1:vcount(data)){
        if(edge_community_object[[1]][i][j]==1){
          #if node i and node j have an edge between them
          if(!j%in%community_index[[temp]]){
            #if the node j is not a member of the particular cluster under consideration
            out_going_cluster_nodes[temp]<-out_going_cluster_nodes[temp]+1
          }
        }
      }
      
    }
  }
  return(out_going_cluster_nodes)
  
}



compute_number_of_nodes_in_cluster<-function(community_object){
  #computing the number of Cluserts ( #C ) using "length(unique(membership(data)))"
  #Computing the number of nodes in each cluster (N_C)
  N_C<-numeric(length(unique(membership(community_object)))) 
  
  #Iterating over the number of clusters
  for(i in 1:length(unique(membership(community_object)))){
    N_C[i]<-sum(membership(community_object)==i)
  }
  return(N_C)
}


#Driver function for computing expansion
run_expansion<-function(data){
  expansion_list<-numeric(9)
  
  expansion_list[8]<-find_expansion(data, walktrap.community(data))
  
}


find_expansion<-function(data,community_object){
  
  out_going_nodes<-compute_outgoing_nodes_from_clusters(data, community_object)
  num_nodes<-compute_number_of_nodes_in_cluster(community_object)
  
}

