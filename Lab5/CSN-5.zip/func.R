

#Computing the number of nodes in each community
num_nodes_each_community<-function(community_object){
  num<-numeric(length(community_object))
  for(i in 1:length(community_object)){
    num[i]<-length(community_object[[i]])
  }
  return(num)
}


#Number of edges inside the cluster
#Number of edges emanating out of the cluster
#Total number of edges belonging to a cluster
#Total number of edges belonging to a graph -- ecount(graph_object)


# Compute the number of edges internal to a cluster
num_internal_edge_each_cluster<-function(data, community_object){
  
  num_edge<-numeric(length(community_object))
  
  edge_community_object<-edge(data)
  #community_index<-
  for(temp in 1:length(community_object)){
    
    for(i in community_object[[temp]]){
      
      for(j in 1:vcount(data)){
        if(edge_community_object[[1]][i][j]==1){
          # That is, if the node i and node j have an edge between them
          if(j%in%community_object[[temp]]){
            #That is, if node j is a member of the particular cluster "temp" under consideration
            num_edge[temp]<-num_edge[temp]+1
          }
        }
      }
    }
  }
  
  return(num_edge)
}





wc_sub<-subgraph(karate, membership(wc)==1)
#count_triangles(wc_sub, V(wc_sub))
#triangles(wc_sub)




count_frac_nodes_triad<-function(data, community_object){
  sum_triad<-numeric(length(community_object))
  #function for computing fraction of nodes in C that belong to a triad (without repetition)
  for(temp in 1:length(community_object)){ 
    sub_g<-induced_subgraph(data, membership(community_object)==temp)
    
    uniq_vert<-sort(unique(triangles(sub_g)))
    if(length(uniq_vert)>0){
      
      some_list<-list()
      for(i in 1:length(uniq_vert)){
        some_list[i]<-list(uniq_vert[i])
      }
      for(i in some_list){
        if(some_list[i]%in%community_object[[temp]]){
          sum_triad<-sum_triad+1
        }
      }
      
    }else{
      sum_triad<-0
    }
    
    }
  return(sum_triad)
}





